/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const run_web: () => void;
export const __wasm_bindgen_func_elem_7782: (a: number, b: number, c: number) => void;
export const __wasm_bindgen_func_elem_7562: (a: number, b: number) => void;
export const __wasm_bindgen_func_elem_9506: (a: number, b: number, c: number) => void;
export const __wasm_bindgen_func_elem_9505: (a: number, b: number) => void;
export const __wasm_bindgen_func_elem_7789: (a: number, b: number, c: number, d: number) => void;
export const __wasm_bindgen_func_elem_7784: (a: number, b: number) => void;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number) => void;
export const __wbindgen_export4: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
